const express = require('express');
const bodyParser = require('body-parser');
const dbConfig = require('./config/db');
const mongoose = require('mongoose');
const UserRoute = require('./routes/user')

const app = express();

app.use('/user', UserRoute)

app.use(bodyParser.urlencoded({ extended: true }))

app.use(bodyParser.json())

app.get('/', (req, res) => {
    res.json({ "message": "Hello Node Express Application" });
});

app.listen(3000, () => {
    console.log("Server is listening on port 3000");
});

mongoose.Promise = global.Promise;

mongoose.connect(dbConfig.url, {
    useNewUrlParser: true,
}).then(() => {
    console.log("Databse Connected Successfully!!");
}).catch(err => {
    console.log('Could not connect to the database', err);
    process.exit();
});

mongoose.set('strictQuery', false);