const express = require('express')
const User = require('../models/user.js')

// Create and Save a new user
exports.create = async (req, res) => {
   /* try {
        console.log("enter in try block")
        let data = req.body
        const email = req.body.email;
        let password = req.body.password;

        let findUser = await UserModel.findOne({ email})
        if (findUser) {
            res.send({
                status: 400,
                message: "email already exist"
            })
        } else {
            new UserModel(data).save(function (err, doc) {
                if (err) console.log(err)
                res.send({
                    status: 200,
                    message: "user added successfully", doc
                })
            })
        }

    } catch (err) {
        console.log("enter in cvatch block")
        res.send({
            status: 403,
            message: err.message
        })
    }*/
    console.log("what in model=====",User.email)
        if (!req.body) {
            return res.status(400).send({
                message: "Please fill all required field"
            });
        }
        // Create a new User
        const user = new User({
           
            email: req.body.email,
            password: req.body.password
        });
        // Save user in the database
        user.save()
            .then(data => {
                res.send(data);
            }).catch(err => {
                res.status(500).send({
                    message: err.message || "Something went wrong while creating new user."
                });
            });
    };



    
   

// Retrieve all users from the database.
exports.findAll = async (req, res) => {
    try {
        const user = await UserModel.find();
        res.status(200).json({ message: "usres fetch successfully", user });
    } catch (error) {
        res.status(404).json({ message: error.message });
    }
};